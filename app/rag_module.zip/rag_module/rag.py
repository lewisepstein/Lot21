# rag_engine.py
import os
import base64
from functools import lru_cache

from dotenv import load_dotenv
from service_utils.db_utils.weaviate_db import WeaviateDB
from weaviate_module.weaviate_utils import load_data_with_tracking

from rag_module.telemetry import Telemetry
from rag_module.understanding_prompts import build_full_understanding_prompt
from rag_module.case_study_prompts import build_project_case_study_prompt
from rag_module.resource_prompts import build_resource_prompt
from rag_module.policy_prompts import build_policy_prompt
from rag_module.newsletter_prompts import build_quarterly_newsletter_prompt


load_dotenv()

MAX_CONTEXT_CHUNKS = 6
MAX_CHARS_PER_CHUNK = 1200
CACHE_SIZE = 128

class RagModule:

    def __init__(self):
        self.client = WeaviateDB().client
        self.collection = self.client.collections.get("training_data")

        import google.generativeai as genai
        genai.configure(api_key=os.getenv("GEMINI_TEXT_API_KEY"))
        self.text_model = genai.GenerativeModel(
            os.getenv("TEXT_MODEL_ID", "gemini-3-flash-preview")
        )

        from google import genai as genai_new
        self.image_client = genai_new.Client(
            api_key=os.getenv("GEMINI_IMAGE_API_KEY"),
            http_options={"api_version": "v1beta"}
        )

    # ---------------- CONTEXT ----------------
    def retrieve_context(self, query: str):
        return self._retrieve_cached(query)

    @lru_cache(maxsize=CACHE_SIZE)
    def _retrieve_cached(self, query):
        res = self.collection.query.bm25(
            query=query,
            limit=MAX_CONTEXT_CHUNKS,
            return_properties=["text", "doc_id"]
        )
        return [
            {"content": o.properties["text"][:MAX_CHARS_PER_CHUNK],
             "doc_id": o.properties["doc_id"]}
            for o in res.objects
        ]

    def _context_str(self, contexts):
        return "\n\n".join(f"Context: {c['content']}" for c in contexts)

    # ---------------- TEXT ----------------
    def generate_content(self, query, category, subpage, context_override, user_id):
        telemetry = Telemetry()

        contexts = self.retrieve_context(query)
        telemetry.mark("weaviate_ms")

        if context_override:
            load_data_with_tracking(scraped_content=query, collection_name="training_data", user_id=user_id)
            self._retrieve_cached.cache_clear()
            contexts = self.retrieve_context(query)

        context_str = self._context_str(contexts)

        # Routing preserved
        if category == 1:
            topic = subpage
            prompt = build_full_understanding_prompt(query, context_str, topic)
        elif category == 2:
            prompt = build_project_case_study_prompt(query, context_str, {})
        elif category == 3:
            prompt = build_resource_prompt(query, context_str, "", "")
        elif category == 4:
            prompt = build_policy_prompt(query, context_str, "", "")
        else:
            prompt = build_quarterly_newsletter_prompt(query, context_str, "Winter", "2025")

        telemetry.add_text_cost(prompt)

        resp = self.text_model.generate_content(prompt)
        telemetry.mark("llm_ms")

        return resp.text, telemetry.export()

    # ---------------- IMAGE ----------------
    def generate_visual(self, prompt):
        if not self.image_client:
            return None

        try:
            from google.genai import types

            resp = self.image_client.models.generate_content(
                model=os.getenv("IMAGE_MODEL_ID"),
                contents=[prompt],
                config=types.GenerateContentConfig(response_modalities=["IMAGE"])
            )

            # --- SAFE EXTRACTION ---
            if not resp or not hasattr(resp, "candidates") or not resp.candidates:
                return None

            candidate = resp.candidates[0]
            if not candidate or not hasattr(candidate, "content") or not candidate.content:
                return None

            parts = getattr(candidate.content, "parts", None)
            if not parts:
                return None

            for part in parts:
                # v1beta inline image data
                if hasattr(part, "inline_data") and part.inline_data:
                    return base64.b64encode(part.inline_data.data).decode("utf-8")

                # fallback image object
                if hasattr(part, "image") and part.image:
                    return base64.b64encode(part.image.image_bytes).decode("utf-8")

        except Exception as e:
            # IMPORTANT: do NOT crash the pipeline
            # Image generation is optional
            return None

        return None


    # ---------------- ENTRY POINT ----------------
    def rag_entry_point(self, query, category=1, subpage=None,
                        context_override=False, user_id=None,
                        image_base_64=None):

        text, telemetry = self.generate_content(
            query, category, subpage, context_override, user_id
        )

        # image = self.generate_visual(query)

        return {
            "text": text,
            # "images": [image] if image else [],
            "telemetry": telemetry
        }
